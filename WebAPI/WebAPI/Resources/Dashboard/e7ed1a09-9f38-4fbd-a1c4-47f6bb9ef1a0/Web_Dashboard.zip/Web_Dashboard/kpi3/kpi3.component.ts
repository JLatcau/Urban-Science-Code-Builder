import { Component , OnInit} from "@angular/core";

@Component({
  selector: 'app-kpi3',
  templateUrl: './kpi3.component.html',
  styleUrls: ['./kpi3.component.css']
})
export class Kpi3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
